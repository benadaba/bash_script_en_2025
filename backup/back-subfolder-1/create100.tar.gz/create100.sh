#!/bin/bash

touch file-{1..10}.py}
